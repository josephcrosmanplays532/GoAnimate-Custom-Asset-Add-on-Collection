3 CUSTOM 009 EYES

Assets created by NathanSB (SaturnBoi)

ASSETS INSTALLATION:

1. Extract the following "009eye_wideopen", "prettygirl009eye", & the "prettygirl009eye_partialopen" folders located in the "eye" folder into "???\store\3a981f5cb2739137\cc_store\family\eye"
& then you can rename them to whatever you want them to be.

2. Add the following into the "cc_theme.xml" file below & then add the same thing but with the other ones above.

		<component type="eye" id="(name)" path="(name)" name="(name)" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="asleep" filename="asleep.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="thinking" filename="thinking.swf"/>
        <state id="yawn" filename="yawn.swf"/>
		</component>

Load up the CW character creator & the asset should be there ready for you to use.

