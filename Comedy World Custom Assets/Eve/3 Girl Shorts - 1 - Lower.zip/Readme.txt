3 GIRL SHORTS ASSETS

Assets created by NathanSB (SaturnBoi)

ASSETS INSTALLATION:

1. Extract the following "eve_shorts1", "eve_shorts2", & the "eve_shorts3" folders located in "eve_lower_body" into "???\store\3a981f5cb2739137\cc_store\family\lower_body"

2. Add the following into the "cc_theme.xml" file below & then add the same thing but with the other ones above.

		<component type="lower_body" id="eve_shorts1" path="eve_shorts1" name="Girl Shorts 1" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
            <state id="chuckle" filename="chuckle.swf"/>
            <state id="crossed_arms" filename="crossed_arms.swf"/>
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="excited.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="point_at" filename="point_at.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sad" filename="sad.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="talk" filename="talk.swf"/>
            <state id="talk_on_phone" filename="talk_on_phone.swf"/>
            <state id="taunt" filename="taunt.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Load up the CW character creator & the asset should be there ready for you to use.

