SPECIAL SKIRT 2

Asset created by NathanSaturnBOI

ASSET INSTALLATION:

1. Extract the "eve_specialskirt2" folder located in "eve_lower_body" into "???\store\3a981f5cb2739137\cc_store\family\lower_body"

2. Add the following into the "cc_theme.xml" file below

		<component type="lower_body" id="eve_specialskirt2" path="eve_specialskirt2" name="Special Skirt 2" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
            <state id="dance" filename="dance.swf"/>
            <state id="default" filename="default.swf"/>
            <state id="excited" filename="default.swf"/>
            <state id="fearful" filename="fearful.swf"/>
            <state id="kneel_down" filename="kneel_down.swf"/>
            <state id="laugh" filename="laugh.swf"/>
            <state id="lie_down" filename="lie_down.swf"/>
            <state id="run" filename="run.swf"/>
            <state id="sit" filename="sit.swf"/>
            <state id="walk" filename="walk.swf"/>
        </component>

Load up the CW character creator & the asset should be there ready for you to use.

