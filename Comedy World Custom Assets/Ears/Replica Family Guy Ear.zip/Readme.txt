REPLICA FAMILY GUY EAR

Asset created by NathanSaturnBOI

ASSET INSTALLATION:

1. Extract the "011" folder into "???\store\3a981f5cb2739137\cc_store\family\ear"

2. Add the following into the "cc_theme.xml" file below

    <component type="ear" id="011" path="011" name="011" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="default" filename="default.swf"/>
    </component>

Load up the CW character creator & the asset should be there ready for you to use.

