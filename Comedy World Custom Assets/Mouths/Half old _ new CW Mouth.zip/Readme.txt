HALF OLD/NEW CW MOUTH ASSET

Asset created by NathanSaturnBOI

ASSET INSTALLATION:

1. Extract the "001a" folder into "???\store\3a981f5cb2739137\cc_store\family\mouth"

2. Add the following into the "cc_theme.xml" file below

		    <component type="mouth" id="001a" path="001a" name="001a" thumb="thumbnail.swf" money="0" sharing="0" enable="Y">
        <state id="angry" filename="angry.swf"/>
        <state id="chewing" filename="chewing.swf"/>
        <state id="cry" filename="cry.swf"/>
        <state id="default" filename="default.swf"/>
        <state id="happy" filename="happy.swf"/>
        <state id="laugh" filename="laugh.swf"/>
        <state id="sad" filename="sad.swf"/>
        <state id="schemeing" filename="schemeing.swf"/>
        <state id="shock" filename="shock.swf"/>
        <state id="sick" filename="sick.swf"/>
        <state id="surprised" filename="surprised.swf"/>
        <state id="talk_a" filename="talk_a.swf"/>
        <state id="talk_angry" filename="talk_angry.swf"/>
        <state id="talk_b" filename="talk_b.swf"/>
        <state id="talk_happy" filename="talk_happy.swf"/>
        <state id="talk_sad" filename="talk_sad.swf"/>
        <state id="taunt" filename="taunt.swf"/>
        <state id="yawn" filename="yawn.swf"/>
		<state id="smile" filename="smile.swf"/>
    </component>

Load up the CW character creator & the asset should be there ready for you to use.

